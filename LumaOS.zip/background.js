chrome.runtime.onMessage.addListener((m) => {
  if (m.type === "open") chrome.tabs.create(m.url ? { url: m.url, active: m.active !== false } : {});
  if (m.type === "popout") chrome.windows.create({ url: m.url, type: "popup", width: 1100, height: 740, focused: true });
});
chrome.commands.onCommand.addListener(async (cmd) => {
  if (cmd !== "toggle-overlay") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) chrome.tabs.sendMessage(tab.id, { type: "toggle" }).catch(() => {});
});
