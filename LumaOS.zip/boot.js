(() => {
  const d = document.documentElement, ls = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
  const t = ls("luma_theme") || "auto";
  const dark = t === "dark" || (t === "auto" && matchMedia("(prefers-color-scheme: dark)").matches);
  d.dataset.theme = dark ? "dark" : "light";
  const b = ls("luma_boot") || "session";
  let seen = false; try { seen = !!sessionStorage.getItem("luma_booted"); sessionStorage.setItem("luma_booted", "1"); } catch {}
  d.dataset.boot = b === "always" || (b === "session" && !seen) ? "on" : "off";
  const a = ls("luma_accent"); if (a) d.style.setProperty("--accent", a);
})();
