/* LumaOS new tab */
const $ = (s, r = document) => r.querySelector(s);
const uid = () => Math.random().toString(36).slice(2, 9);
const mod = /Mac/i.test(navigator.platform) ? "\u2318" : "Ctrl+";

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === "class") e.className = v;
    else if (k === "html") e.innerHTML = v;
    else if (k === "style") e.style.cssText = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) { if (c == null || c === false) continue; e.append(c.nodeType ? c : document.createTextNode(c)); }
  return e;
}
const ic = (n, s = 16, sw) => h("span", { class: "ic", html: lumaIcon(n, s, sw) });
const logoSvg = (s) => `<svg width="${s}" height="${s}" viewBox="0 0 48 48"><circle cx="24" cy="24" r="21" fill="url(#lumaGrad)"/><path d="M24 3a21 21 0 0 1 0 42 14 14 0 0 0 0-42z" fill="#fff" fill-opacity=".25"/><circle cx="24" cy="24" r="6.5" fill="#fff"/></svg>`;
const monoLogo = `<svg class="mb-logo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="2.6" fill="currentColor" stroke="none"/></svg>`;

const WALLS = [
  { id: "aurora", name: "Aurora", css: "radial-gradient(60% 55% at 15% 10%,#ffb36b,transparent 62%),radial-gradient(55% 55% at 90% 15%,#8a6bff,transparent 64%),radial-gradient(75% 60% at 55% 110%,#1f6fff,transparent 66%),linear-gradient(160deg,#3a1c71,#d76d77 60%,#ffaf7b)" },
  { id: "lagoon", name: "Lagoon", css: "radial-gradient(60% 55% at 85% 10%,#7cf7d4,transparent 62%),radial-gradient(60% 60% at 10% 90%,#1d6fd6,transparent 64%),linear-gradient(150deg,#0b3d5c,#12a3a8 70%,#8ef0e0)" },
  { id: "orchid", name: "Orchid", css: "radial-gradient(60% 55% at 20% 15%,#ff9ad5,transparent 62%),radial-gradient(60% 60% at 85% 85%,#5b6cff,transparent 64%),linear-gradient(155deg,#4b1d6b,#c14fa8 65%,#ffb3d9)" },
  { id: "ember", name: "Ember", css: "radial-gradient(60% 55% at 80% 10%,#ffd166,transparent 60%),radial-gradient(70% 60% at 15% 95%,#c1121f,transparent 66%),linear-gradient(160deg,#2b0a1e,#d7263d 60%,#ff8c42)" },
  { id: "meadow", name: "Meadow", css: "radial-gradient(60% 55% at 15% 15%,#eaff8a,transparent 62%),radial-gradient(65% 60% at 85% 90%,#0f9d7a,transparent 66%),linear-gradient(155deg,#134e4a,#4cb85f 65%,#d6f26b)" },
  { id: "midnight", name: "Midnight", css: "radial-gradient(55% 50% at 75% 18%,#6a4cff,transparent 62%),radial-gradient(65% 60% at 20% 95%,#0f4c81,transparent 66%),linear-gradient(170deg,#07071a,#1a1650 70%,#2b2377)" },
  { id: "slate", name: "Slate", css: "radial-gradient(60% 55% at 20% 10%,#5c6b82,transparent 62%),linear-gradient(160deg,#171b24,#2d3646 70%,#4a566b)" },
  { id: "dune", bright: true, name: "Dune", css: "radial-gradient(60% 55% at 85% 12%,#fff1d6,transparent 62%),radial-gradient(70% 60% at 15% 95%,#e8a87c,transparent 66%),linear-gradient(160deg,#f6d6a8,#e29578 70%,#c86b5a)" },
  { id: "polar", bright: true, name: "Polar", css: "radial-gradient(60% 55% at 20% 10%,#ffffff,transparent 62%),radial-gradient(70% 60% at 85% 95%,#9ec5ff,transparent 66%),linear-gradient(160deg,#dbe9ff,#b8d3f5 70%,#8fb6ee)" }
];

const mkItem = (name, url) => ({ id: uid(), name, url, icon: "", data: "" });
const defaults = () => ({
  v: 2, theme: "auto", accent: "#0a84ff", wp: "aurora", glass: .5, blur: 34, iconSize: 64,
  boot: "session", overlay: true, side: "right", openIn: "same", showGreeting: true, showSearch: true, engine: "google", name: "", autoName: "", active: "fav",
  spaces: [
    { id: "fav", name: "Favorites", icon: "star", color: "#ff9f0a", items: [
      mkItem("Google", "https://www.google.com"), mkItem("YouTube", "https://www.youtube.com"), mkItem("Gmail", "https://mail.google.com"),
      mkItem("GitHub", "https://github.com"), mkItem("Maps", "https://maps.google.com")] },
    { id: "work", name: "Work", icon: "briefcase", color: "#0a84ff", items: [] },
    { id: "fun", name: "Fun", icon: "game", color: "#bf5af2", items: [] }
  ]
});

let S, customWp = null, dragId = null;
const cur = () => S.spaces.find((s) => s.id === S.active) || S.spaces[0];
const save = () => chrome.storage.local.set({ luma: S });
const colorFor = (s) => `hsl(${[...s].reduce((a, c) => a + c.charCodeAt(0), 0) % 360} 55% 50%)`;
const favUrl = (u) => { try { return `https://www.google.com/s2/favicons?sz=128&domain=${new URL(u).hostname}`; } catch { return ""; } };
function normalizeUrl(v) {
  v = (v || "").trim(); if (!v) return null;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(v)) v = "https://" + v;
  try { const u = new URL(v); return /^https?:$/.test(u.protocol) ? u.href : null; } catch { return null; }
}

async function load() {
  const r = await chrome.storage.local.get(["luma", "luma_wp", "desk"]);
  customWp = r.luma_wp || null;
  if (r.luma) S = { ...defaults(), ...r.luma };
  else {
    S = defaults();
    if (r.desk && r.desk.spaces) {
      S.spaces = r.desk.spaces.map((sp, i) => ({ id: sp.id, name: sp.name, icon: "folder", color: LUMA_COLORS[i % LUMA_COLORS.length], items: (sp.items || []).map((it) => ({ ...mkItem(it.name, it.url), icon: it.icon || "" })) }));
      S.active = r.desk.active || S.spaces[0].id;
    }
    save();
  }
}

/* ---------- Look ---------- */
const mq = matchMedia("(prefers-color-scheme: dark)");
const isDark = () => S.theme === "dark" || (S.theme === "auto" && mq.matches);
function applyLook() {
  const r = document.documentElement;
  r.dataset.theme = isDark() ? "dark" : "light";
  r.style.setProperty("--accent", S.accent);
  r.style.setProperty("--ga", S.glass);
  r.style.setProperty("--blur", S.blur + "px");
  r.style.setProperty("--isz", S.iconSize + "px");
  try { localStorage.setItem("luma_theme", S.theme); localStorage.setItem("luma_boot", S.boot); localStorage.setItem("luma_accent", S.accent); } catch {}
}
mq.addEventListener("change", () => { if (S) { applyLook(); renderBar(); } });
function setTheme(t) { S.theme = t; applyLook(); save(); renderBar(); renderSidebar(); if (wins.has("prism")) wins.get("prism").show?.(); }
let wallKey = "";
function sampleTone(src) {
  const img = new Image();
  img.onload = () => {
    try {
      const c = document.createElement("canvas"); c.width = 40; c.height = 4;
      const x = c.getContext("2d"); x.drawImage(img, 0, 0, img.width, img.height * .06, 0, 0, 40, 4);
      const d = x.getImageData(0, 0, 40, 4).data; let l = 0;
      for (let i = 0; i < d.length; i += 4) l += (.2126 * d[i] + .7152 * d[i + 1] + .0722 * d[i + 2]) / 255;
      document.documentElement.dataset.bar = l / (d.length / 4) > .62 ? "bright" : "dark";
    } catch {}
  };
  img.src = src;
}
function applyWall() {
  const css = S.wp === "custom" && customWp ? `url("${customWp}") center/cover` : (WALLS.find((w) => w.id === S.wp) || WALLS[0]).css;
  if (css === wallKey) return; wallKey = css;
  const preset = WALLS.find((x) => x.id === S.wp);
  if (S.wp === "custom" && customWp) sampleTone(customWp); else document.documentElement.dataset.bar = preset && preset.bright ? "bright" : "dark";
  const box = $("#wallpaper"), el = h("div", { class: "wp", style: `background:${css}` });
  box.append(el);
  requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add("in")));
  setTimeout(() => { while (box.children.length > 1) box.firstChild.remove(); }, 950);
}

/* ---------- Toast ---------- */
function toast(msg) {
  const t = h("div", { class: "toast glass" }, msg);
  $("#layer").append(t);
  setTimeout(() => { t.classList.add("out"); setTimeout(() => t.remove(), 260); }, 2200);
}

/* ---------- Menus ---------- */
let curMenu = null;
function showMenu(entries, { x = 0, y = 0, anchor } = {}) {
  closeMenu(true);
  const m = h("div", { class: "menu glass" });
  for (const en of entries) {
    if (en === "-") { m.append(h("hr")); continue; }
    if (en.header) { m.append(h("div", { class: "mh" }, en.label)); continue; }
    m.append(h("button", { class: "mi" + (en.danger ? " danger" : ""), disabled: en.disabled, onclick: () => { closeMenu(); en.run && en.run(); } },
      h("span", { class: "mck" }, en.checked ? ic("check", 14, 2.4) : null), h("span", { class: "ml" }, en.label), en.key ? h("span", { class: "mk" }, en.key) : null));
  }
  $("#layer").append(m);
  const r = m.getBoundingClientRect();
  let px = anchor ? anchor.getBoundingClientRect().left : x, py = anchor ? anchor.getBoundingClientRect().bottom + 4 : y;
  px = Math.max(8, Math.min(px, innerWidth - r.width - 8)); py = Math.max(32, Math.min(py, innerHeight - r.height - 8));
  m.style.left = px + "px"; m.style.top = py + "px";
  curMenu = { el: m, anchor }; if (anchor) anchor.classList.add("open");
}
function closeMenu(instant) {
  if (!curMenu) return; const { el, anchor } = curMenu; curMenu = null;
  if (anchor) anchor.classList.remove("open");
  if (instant) el.remove(); else { el.classList.add("out"); setTimeout(() => el.remove(), 120); }
}
document.addEventListener("pointerdown", (e) => {
  if (curMenu && !curMenu.el.contains(e.target) && !(curMenu.anchor && curMenu.anchor.contains(e.target))) closeMenu();
  if (launcher && !launcher.el.contains(e.target) && !e.target.closest(".luma, [data-launch]")) closeLauncher();
  if ($("#sidebar").classList.contains("open") && !e.target.closest("#sidebar, #sideHandle, .win, .menu")) toggleSidebar(false);
});
addEventListener("blur", () => closeMenu());

/* ---------- Menu bar ---------- */
let barOpen = null;
function renderBar() {
  const bar = $("#menubar"); bar.textContent = ""; barOpen = null;
  const menus = {
    luma: () => [
      { label: "About LumaOS", run: () => openSettings("about") }, "-",
      { label: "Prism Settings\u2026", key: mod + ",", run: () => openSettings() }, "-",
      { header: true, label: "Appearance" },
      ...["light", "dark", "auto"].map((t) => ({ label: { light: "Light", dark: "Dark", auto: "Auto" }[t], checked: S.theme === t, run: () => setTheme(t) })), "-",
      { label: "Replay Startup Animation", run: replayBoot }],
    file: () => [
      { label: "New Shortcut\u2026", run: () => editShortcut() }, { label: "New Category\u2026", run: () => editSpace() }, "-",
      { label: "Save Open Tabs Here", run: saveTabs }, "-",
      { label: "Export Layout\u2026", run: exportLayout }, { label: "Import Layout\u2026", run: () => $("#importFile").click() }],
    view: () => [
      { label: $("#sidebar").classList.contains("open") ? "Hide Sidebar" : "Show Sidebar", run: () => toggleSidebar() },
      { label: "Launcher", key: mod + "K", run: openLauncher }, "-",
      { label: "Next Wallpaper", run: nextWall }, "-",
      { header: true, label: "Icon Size" },
      ...[["Small", 52], ["Medium", 64], ["Large", 80]].map(([l, v]) => ({ label: l, checked: S.iconSize === v, run: () => setIconSize(v) }))],
    cats: () => S.spaces.map((sp, i) => ({ label: sp.name, checked: sp.id === S.active, key: i < 9 ? mod + (i + 1) : "", run: () => setActive(sp.id) })),
    window: () => [...wins.values()].length
      ? [...[...wins.values()].map((w) => ({ label: w.title, checked: w.focused && !w.min, run: () => { restoreWin(w); focusWin(w); } })), "-", { label: "Close All Windows", run: () => [...wins.values()].forEach(closeWin) }]
      : [{ label: "No open windows", disabled: true }]
  };
  const mk = (key, content, cls = "") => {
    const b = h("button", { class: "mb " + cls, onclick: () => { if (barOpen === b && curMenu) { closeMenu(); barOpen = null; } else { showMenu(menus[key](), { anchor: b }); barOpen = b; } },
      onpointerenter: () => { if (curMenu && barOpen && barOpen !== b) { showMenu(menus[key](), { anchor: b }); barOpen = b; } } }, content);
    return b;
  };
  bar.append(
    h("div", { class: "mbg" },
      mk("luma", [h("span", { html: monoLogo }), h("span", { class: "strong", style: "font-weight:700" }, "LumaOS")]),
      mk("file", "File"), mk("view", "View"), mk("cats", "Categories"), mk("window", "Window")),
    h("div", { class: "mbg" },
      h("button", { class: "mb", title: "Launcher (" + mod + "K)", onclick: openLauncher, "data-launch": true }, ic("search", 15, 2)),
      h("button", { class: "mb", title: "Toggle light and dark", onclick: () => setTheme(isDark() ? "light" : "dark") }, ic(isDark() ? "moon" : "sun", 15, 2)),
      h("span", { id: "clock" })));
  tick();
}
function tick() {
  updateGreet();
  const c = $("#clock"); if (!c) return;
  c.textContent = new Date().toLocaleString("en-GB", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).replace(",", "");
}

/* ---------- Icons ---------- */
async function toData(url) {
  const r = await fetch(url); if (!r.ok) throw new Error("fetch");
  const b = await r.blob(); if (!b.type.startsWith("image/")) throw new Error("type");
  return await new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); });
}
let fetching = false;
async function ensureIcons() {
  if (fetching) return; fetching = true; let changed = false;
  for (const sp of S.spaces) for (const it of sp.items) {
    if (it.data) continue;
    try { it.data = await toData(it.icon || favUrl(it.url)); changed = true; } catch { it.data = ""; }
  }
  fetching = false;
  if (changed) { save(); renderDesktop(false); renderLauncherIfOpen(); }
}
function makeTile(item) {
  const t = h("div", { class: "tile" + (item.icon ? " photo" : "") });
  const letter = () => { t.className = "tile"; t.textContent = ""; t.append(h("div", { class: "letter", style: `background:${colorFor(item.name || "?")}` }, ((item.name || "?")[0] || "?").toUpperCase())); };
  const src = item.data || item.icon || favUrl(item.url);
  if (!src) { letter(); return t; }
  const img = h("img", { draggable: "false", alt: "", src }); img.onerror = letter; t.append(img);
  return t;
}

/* ---------- Desktop ---------- */
function openItem(it, e) {
  if (e && (e.metaKey || e.ctrlKey)) chrome.tabs.create({ url: it.url, active: false });
  else if (S.openIn === "tab") chrome.tabs.create({ url: it.url });
  else location.href = it.url;
}
const popOut = (it) => chrome.windows.create({ url: it.url, type: "popup", width: 1100, height: 740, focused: true });

function renderDesktop(anim = true) {
  const d = $("#desktop"), sp = cur(); d.textContent = "";
  $("#hint").hidden = sp.items.length > 0;
  sp.items.forEach((item, i) => {
    const el = h("button", { class: "icon", draggable: "true", title: item.url, style: `--i:${i}` }, makeTile(item), h("span", { class: "name" }, item.name));
    el.addEventListener("click", (e) => openItem(item, e));
    el.addEventListener("auxclick", (e) => { if (e.button === 1) chrome.tabs.create({ url: item.url, active: false }); });
    el.addEventListener("contextmenu", (e) => { e.preventDefault(); e.stopPropagation(); showMenu([
      { label: "Open", run: () => openItem(item) },
      { label: "Open in New Tab", run: () => chrome.tabs.create({ url: item.url }) },
      { label: "Pop Out", run: () => popOut(item) }, "-",
      { label: "Edit\u2026", run: () => editShortcut(item) },
      { label: "Move to", disabled: true },
      ...S.spaces.filter((s) => s.id !== sp.id).map((s) => ({ label: "   " + s.name, run: () => moveItem(item.id, s.id) })), "-",
      { label: "Delete", danger: true, run: () => { sp.items = sp.items.filter((x) => x !== item); save(); renderDesktop(false); renderSidebar(); } }], { x: e.clientX, y: e.clientY }); });
    el.addEventListener("dragstart", () => { dragId = item.id; el.classList.add("dragging"); });
    el.addEventListener("dragend", () => { dragId = null; el.classList.remove("dragging"); });
    el.addEventListener("dragover", (e) => { if (dragId) { e.preventDefault(); el.classList.add("drop"); } });
    el.addEventListener("dragleave", () => el.classList.remove("drop"));
    el.addEventListener("drop", (e) => {
      e.preventDefault(); el.classList.remove("drop");
      if (!dragId || dragId === item.id) return;
      const from = sp.items.findIndex((x) => x.id === dragId); if (from < 0) return;
      const [m] = sp.items.splice(from, 1); sp.items.splice(sp.items.findIndex((x) => x.id === item.id), 0, m);
      save(); renderDesktop(false);
    });
    d.append(el);
  });
  if (anim) d.animate([{ opacity: 0, transform: "scale(.985)" }, { opacity: 1, transform: "none" }], { duration: 300, easing: "cubic-bezier(.22,1,.36,1)" });
}
function moveItem(id, toId) {
  const from = cur(), to = S.spaces.find((s) => s.id === toId); if (!to || to === from) return;
  const i = from.items.findIndex((x) => x.id === id); if (i < 0) return;
  to.items.push(...from.items.splice(i, 1)); save(); renderDesktop(false); renderSidebar(); toast(`Moved to ${to.name}`);
}
function setActive(id) { S.active = id; save(); renderDock(); renderSidebar(); renderDesktop(true); }
function setIconSize(v) { S.iconSize = v; applyLook(); save(); }
function nextWall() { const i = WALLS.findIndex((w) => w.id === S.wp); S.wp = WALLS[(i + 1) % WALLS.length].id; applyWall(); save(); }
function sortIcons() { cur().items.sort((a, b) => a.name.localeCompare(b.name)); save(); renderDesktop(false); }
async function saveTabs() {
  const tabs = await chrome.tabs.query({ currentWindow: true }), sp = cur(); let n = 0;
  for (const t of tabs) {
    if (!/^https?:/.test(t.url || "") || sp.items.some((i) => i.url === t.url)) continue;
    let name = (t.title || "").trim() || new URL(t.url).hostname; if (name.length > 36) name = name.slice(0, 34) + "\u2026";
    sp.items.push({ id: uid(), name, url: t.url, icon: "", data: "" }); n++;
  }
  save(); renderDesktop(false); renderSidebar(); ensureIcons();
  toast(n ? `Saved ${n} tab${n > 1 ? "s" : ""} to ${sp.name}` : "No new tabs to save");
}
const desktopMenu = () => [
  { label: "New Shortcut\u2026", run: () => editShortcut() }, { label: "New Category\u2026", run: () => editSpace() },
  { label: "Save Open Tabs Here", run: saveTabs }, "-",
  { label: "Sort Icons by Name", run: sortIcons }, { label: "Change Wallpaper", run: nextWall }, "-",
  { label: "Prism Settings\u2026", key: mod + ",", run: () => openSettings() }];
document.addEventListener("contextmenu", (e) => {
  if (e.target.closest("input")) return;
  e.preventDefault();
  if (e.target.closest(".win, .menu, #dock, .launcher, #sidebar, #menubar, .icon")) return;
  showMenu(desktopMenu(), { x: e.clientX, y: e.clientY });
});

/* ---------- Dock ---------- */
function dockItem({ label, tile, cls = "", color, active, onclick, oncontext, drop }) {
  const d = h("div", { class: "dock-item " + cls + (active ? " active" : ""), "data-label": label, style: color ? `--c:${color}` : "", onclick }, h("div", { class: "dtile" }, tile), h("div", { class: "dot" }));
  if (oncontext) d.addEventListener("contextmenu", (e) => { e.preventDefault(); e.stopPropagation(); oncontext(e); });
  if (drop) {
    d.addEventListener("dragover", (e) => { if (dragId) { e.preventDefault(); d.classList.add("over"); } });
    d.addEventListener("dragleave", () => d.classList.remove("over"));
    d.addEventListener("drop", (e) => { e.preventDefault(); d.classList.remove("over"); drop(); });
  }
  return d;
}
let rest = null;
function renderDock() {
  const dock = $("#dock"); dock.textContent = ""; rest = null;
  dock.append(dockItem({ label: "Launcher", cls: "luma", tile: h("span", { html: logoSvg(34) }), onclick: openLauncher }));
  dock.append(h("div", { class: "dock-sep" }));
  for (const sp of S.spaces) dock.append(dockItem({ label: sp.name, color: sp.color, active: sp.id === S.active, tile: h("span", { class: "ic", html: lumaIcon(sp.icon, 28, 1.9) }),
    onclick: () => setActive(sp.id), oncontext: (e) => spaceMenu(e, sp), drop: () => moveItem(dragId, sp.id) }));
  dock.append(dockItem({ label: "New Category", cls: "add", tile: ic("plus", 24, 1.9), onclick: () => editSpace() }));
  const mins = [...wins.values()].filter((w) => w.min);
  if (mins.length) {
    dock.append(h("div", { class: "dock-sep" }));
    mins.forEach((w) => dock.append(dockItem({ label: w.title, cls: "win", tile: ic(w.icon, 24, 1.8), onclick: () => { restoreWin(w); focusWin(w); } })));
  }
}
const dockEl = $("#dock");
dockEl.addEventListener("pointermove", (e) => {
  if (!rest) rest = [...dockEl.querySelectorAll(".dock-item")].map((el) => { const r = el.getBoundingClientRect(); return { el, cx: r.left + r.width / 2 }; });
  for (const { el, cx } of rest) {
    const d = Math.abs(e.clientX - cx), s = 1 + .62 * Math.pow(Math.cos(Math.min(d / 140, 1) * Math.PI / 2), 2);
    el.firstChild.style.transform = `scale(${s})`; el.style.margin = `0 ${(s - 1) * 28}px`; el.style.setProperty("--lift", (s - 1) * 56 + "px");
  }
});
dockEl.addEventListener("pointerleave", () => {
  rest = null;
  for (const el of dockEl.querySelectorAll(".dock-item")) { el.firstChild.style.transform = ""; el.style.margin = ""; el.style.setProperty("--lift", "0px"); }
});
const spaceMenu = (e, sp) => showMenu([{ label: "Edit Category\u2026", run: () => editSpace(sp) }, { label: "Delete Category", danger: true, run: () => deleteSpace(sp) }], { x: e.clientX, y: e.clientY });
function deleteSpace(sp) {
  if (S.spaces.length === 1) return toast("You need at least one category");
  confirmBox({ title: `Delete "${sp.name}"?`, msg: `Its ${sp.items.length} shortcut${sp.items.length === 1 ? "" : "s"} will be removed.`, ok: "Delete", danger: true, run: () => {
    S.spaces = S.spaces.filter((s) => s !== sp); if (S.active === sp.id) S.active = S.spaces[0].id; save(); renderDock(); renderDesktop(true); renderSidebar(); } });
}

/* ---------- Sidebar ---------- */
function toggleSidebar(force) {
  const sb = $("#sidebar"), open = force ?? !sb.classList.contains("open");
  sb.classList.toggle("open", open); document.body.classList.toggle("sb-open", open);
}
$("#sideHandle").addEventListener("click", () => toggleSidebar());
function renderSidebar() {
  const sb = $("#sidebar"); sb.textContent = "";
  const row = (icon, label, run, extra = {}) => h("button", { class: "sb-i" + (extra.on ? " on" : ""), onclick: run, oncontextmenu: extra.ctx },
    h("span", { class: "sb-ic" + (extra.plain ? " plain" : ""), style: extra.color ? `--c:${extra.color}` : "", html: lumaIcon(icon, 14, 2) }), h("span", { class: "sb-n" }, label), extra.count != null ? h("span", { class: "sb-c" }, String(extra.count)) : null);
  sb.append(h("div", { class: "sb-h" }, "Categories"),
    ...S.spaces.map((sp) => row(sp.icon, sp.name, () => setActive(sp.id), { on: sp.id === S.active, color: sp.color, count: sp.items.length, ctx: (e) => { e.preventDefault(); spaceMenu(e, sp); } })),
    row("plus", "New Category", () => editSpace(), { plain: true }),
    h("div", { class: "sb-h" }, "Quick actions"),
    row("plus", "New Shortcut", () => editShortcut(), { plain: true }),
    row("download", "Save Open Tabs", saveTabs, { plain: true }),
    row("search", "Launcher", openLauncher, { plain: true }),
    row("sliders", "Prism Settings", () => openSettings(), { plain: true }),
    h("div", { class: "sb-grow" }),
    h("div", { class: "sb-foot" }, seg([["light", "Light"], ["auto", "Auto"], ["dark", "Dark"]], S.theme, setTheme)));
}

/* ---------- Controls ---------- */
function seg(opts, val, on) {
  return h("div", { class: "seg" }, opts.map(([v, l]) => h("button", { class: v === val ? "on" : "", onclick: (e) => { on(v); [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle("on", b === e.currentTarget)); } }, l)));
}
function sw(val, on) { const e = h("button", { class: "sw" + (val ? " on" : ""), role: "switch" }); e.onclick = () => { e.classList.toggle("on"); on(e.classList.contains("on")); }; return e; }
const row = (title, sub, ctl) => h("div", { class: "row" }, h("div", {}, h("div", {}, title), sub ? h("div", { class: "sub" }, sub) : null), ctl);
const range = (min, max, step, val, on) => h("input", { type: "range", min, max, step, value: val, oninput: (e) => on(+e.target.value), onchange: save });

/* ---------- Windows ---------- */
const wins = new Map(); let zTop = 100;
const glyph = (p) => h("span", { html: `<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="rgba(0,0,0,.55)" stroke-width="1.3" stroke-linecap="round"><path d="${p}"/></svg>` });
function createWindow(o) {
  if (o.id && wins.has(o.id)) { const w = wins.get(o.id); restoreWin(w); focusWin(w); return w; }
  const w = { id: o.id || uid(), title: o.title, icon: o.icon || "window", min: false, max: false, focused: false };
  const bar = h("div", { class: "titlebar" },
    h("div", { class: "lights" },
      h("button", { class: "lt r", title: "Close", onclick: () => closeWin(w) }, glyph("M3.5 3.5l5 5M8.5 3.5l-5 5")),
      h("button", { class: "lt y", title: "Minimize", onclick: () => minWin(w) }, glyph("M3 6h6")),
      h("button", { class: "lt g", title: "Zoom", onclick: () => maxWin(w) }, glyph("M3.5 6h5M6 3.5v5"))),
    h("div", { class: "wtitle" }, o.title));
  const body = h("div", { class: "wbody" + (o.pad ? " pad" : "") });
  w.el = h("div", { class: "win glass", style: `width:${o.w || 440}px;` + (o.h ? `height:${o.h}px;` : "") }, bar, body);
  w.body = body;
  $("#windows").append(w.el); wins.set(w.id, w);
  const off = (wins.size - 1) * 26 % 130, r = w.el.getBoundingClientRect();
  w.el.style.left = Math.max(8, (innerWidth - r.width) / 2 + off) + "px"; w.el.style.top = Math.max(44, (innerHeight - r.height) / 2 - 30 + off) + "px";
  bar.addEventListener("pointerdown", (e) => {
    if (e.target.closest(".lights") || w.max) return; focusWin(w);
    const rc = w.el.getBoundingClientRect(), dx = e.clientX - rc.left, dy = e.clientY - rc.top;
    w.el.classList.add("dragging"); bar.setPointerCapture(e.pointerId);
    const mv = (ev) => { w.el.style.left = Math.max(-rc.width + 90, Math.min(innerWidth - 90, ev.clientX - dx)) + "px"; w.el.style.top = Math.max(32, Math.min(innerHeight - 70, ev.clientY - dy)) + "px"; };
    const up = () => { w.el.classList.remove("dragging"); bar.removeEventListener("pointermove", mv); bar.removeEventListener("pointerup", up); };
    bar.addEventListener("pointermove", mv); bar.addEventListener("pointerup", up);
  });
  bar.addEventListener("dblclick", (e) => { if (!e.target.closest(".lights")) maxWin(w); });
  w.el.addEventListener("pointerdown", () => focusWin(w), true);
  o.build(w, body); focusWin(w); return w;
}
function focusWin(w) { zTop++; w.el.style.zIndex = zTop; for (const x of wins.values()) { x.focused = x === w; x.el.classList.toggle("focus", x === w); } }
function closeWin(w) { if (!wins.has(w.id)) return; wins.delete(w.id); w.el.classList.add("closing"); setTimeout(() => w.el.remove(), 170); renderDock(); const n = [...wins.values()].filter((x) => !x.min).pop(); if (n) focusWin(n); }
function minWin(w) {
  const d = dockEl.getBoundingClientRect(), r = w.el.getBoundingClientRect();
  w.el.style.transform = `translate(${d.left + d.width / 2 - (r.left + r.width / 2)}px,${d.top + d.height / 2 - (r.top + r.height / 2)}px) scale(.1)`; w.el.style.opacity = "0";
  w.min = true; w.focused = false; w.el.classList.remove("focus"); renderDock();
  setTimeout(() => { if (w.min) w.el.classList.add("hidden"); }, 430);
}
function restoreWin(w) { if (!w.min) return; w.min = false; w.el.classList.remove("hidden"); void w.el.offsetWidth; w.el.style.transform = ""; w.el.style.opacity = ""; renderDock(); }
function maxWin(w) {
  const el = w.el;
  if (!w.max) { w.prev = { l: el.offsetLeft, t: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight }; Object.assign(el.style, { left: "8px", top: "38px", width: innerWidth - 16 + "px", height: innerHeight - 38 - 104 + "px" }); w.max = true; }
  else { Object.assign(el.style, { left: w.prev.l + "px", top: w.prev.t + "px", width: w.prev.w + "px", height: w.prev.h + "px" }); w.max = false; }
}
function confirmBox({ title, msg, ok = "OK", danger, run }) {
  const w = createWindow({ id: "confirm", title: "LumaOS", w: 340, icon: "info", build: (w, b) => {
    b.classList.add("confirm");
    b.append(h("p", { style: "color:var(--fg);font-weight:600;font-size:14px" }, title), h("p", {}, msg),
      h("div", { class: "btns", style: "padding:0 22px 20px" }, h("button", { class: "btn", onclick: () => closeWin(w) }, "Cancel"), h("button", { class: "btn " + (danger ? "danger" : "primary"), onclick: () => { closeWin(w); run(); } }, ok)));
  } });
}

/* ---------- Editors ---------- */
const closeById = (id) => { const w = wins.get(id); if (w) closeWin(w); };
function field(label, input) { return h("label", { class: "fld" }, h("span", {}, label), input); }
function editShortcut(item) {
  closeById("edit");
  const isNew = !item;
  const name = h("input", { type: "text", value: item?.name || "", placeholder: "YouTube", required: true });
  const url = h("input", { type: "text", value: item?.url || "", placeholder: "youtube.com", required: true });
  const icon = h("input", { type: "text", value: item?.icon || "", placeholder: "https://example.com/logo.png" });
  const pv = h("div", { class: "pv" });
  let t; const upd = () => { clearTimeout(t); t = setTimeout(() => { pv.textContent = ""; const u = normalizeUrl(url.value); pv.append(makeTile({ name: name.value || "?", url: u || "", icon: icon.value.trim(), data: "" })); }, 350); };
  [name, url, icon].forEach((i) => i.addEventListener("input", upd));
  createWindow({ id: "edit", title: isNew ? "New Shortcut" : "Edit Shortcut", icon: "plus", w: 380, pad: true, build: (w, b) => {
    const form = h("form", { onsubmit: (e) => {
      e.preventDefault();
      const u = normalizeUrl(url.value), host = u ? new URL(u).hostname : "";
      if (!u || !(host.includes(".") || host === "localhost")) return toast("Enter a valid website address");
      const data = { name: name.value.trim(), url: u, icon: icon.value.trim() };
      if (isNew) cur().items.push({ id: uid(), ...data, data: "" });
      else { if (item.url !== u || item.icon !== data.icon) item.data = ""; Object.assign(item, data); }
      save(); renderDesktop(false); renderSidebar(); ensureIcons(); closeWin(w);
    } }, pv, field("Name", name), field("Website", url), field("Custom icon URL (optional)", icon),
      h("div", { class: "btns" }, h("button", { type: "button", class: "btn", onclick: () => closeWin(w) }, "Cancel"), h("button", { type: "submit", class: "btn primary" }, isNew ? "Add" : "Save")));
    b.append(form); upd(); setTimeout(() => name.focus(), 60);
  } });
}
function editSpace(sp) {
  closeById("space");
  const isNew = !sp; let icon = sp?.icon || "folder", color = sp?.color || LUMA_COLORS[S.spaces.length % LUMA_COLORS.length];
  const name = h("input", { type: "text", value: sp?.name || "", placeholder: "School", required: true });
  createWindow({ id: "space", title: isNew ? "New Category" : "Edit Category", icon: "folder", w: 400, pad: true, build: (w, b) => {
    const picker = h("div", { class: "picker" }), sws = h("div", { class: "sws", style: "margin-bottom:6px" });
    const draw = () => {
      picker.textContent = ""; sws.textContent = "";
      LUMA_CAT_ICONS.forEach((n) => picker.append(h("button", { type: "button", class: "pk" + (n === icon ? " on" : ""), onclick: () => { icon = n; draw(); } }, ic(n, 18))));
      LUMA_COLORS.forEach((c) => sws.append(h("button", { type: "button", class: "swc" + (c === color ? " on" : ""), style: `background:${c}`, onclick: () => { color = c; draw(); } })));
    }; draw();
    b.append(h("form", { onsubmit: (e) => {
      e.preventDefault(); const n = name.value.trim(); if (!n) return;
      if (isNew) { const s = { id: uid(), name: n, icon, color, items: [] }; S.spaces.push(s); S.active = s.id; } else Object.assign(sp, { name: n, icon, color });
      save(); renderDock(); renderSidebar(); renderDesktop(isNew); closeWin(w);
    } }, field("Name", name), h("div", { class: "fld" }, h("span", {}, "Icon"), picker), h("div", { class: "fld" }, h("span", {}, "Color"), sws),
      h("div", { class: "btns" }, h("button", { type: "button", class: "btn", onclick: () => closeWin(w) }, "Cancel"), h("button", { type: "submit", class: "btn primary" }, isNew ? "Create" : "Save"))));
    setTimeout(() => name.focus(), 60);
  } });
}

/* ---------- Prism Settings ---------- */
const SECTIONS = [["appearance", "Appearance", "sun", "#0a84ff"], ["wallpaper", "Wallpaper", "image", "#bf5af2"], ["home", "Home", "home", "#ff375f"], ["desktop", "Desktop", "desktop", "#30d158"], ["overlay", "Site Panel", "layers", "#ff9f0a"], ["about", "About", "info", "#8e8e93"]];
function openSettings(sec = "appearance") {
  const existing = wins.get("prism");
  if (existing) { existing.show(sec); restoreWin(existing); focusWin(existing); return; }
  createWindow({ id: "prism", title: "Prism Settings", icon: "sliders", w: 700, h: 500, build: (w, b) => {
    const nav = h("div", { class: "set-nav" }), main = h("div", { class: "set-main" });
    b.style.overflow = "hidden"; b.append(h("div", { class: "set" }, nav, main));
    let current = sec;
    w.show = (s) => {
      if (s) current = s; nav.textContent = ""; main.textContent = "";
      SECTIONS.forEach(([id, label, icon, c]) => nav.append(h("button", { class: "nav-i" + (id === current ? " on" : ""), onclick: () => w.show(id) }, h("span", { class: "nav-ic", style: `--c:${c}`, html: lumaIcon(icon, 13, 2) }), label)));
      main.append(...SEC[current]());
    };
    w.show(sec);
  } });
}
const swatches = () => h("div", { class: "sws" }, ...LUMA_COLORS.map((c) => h("button", { class: "swc" + (S.accent.toLowerCase() === c ? " on" : ""), style: `background:${c}`, onclick: () => { S.accent = c; applyLook(); save(); wins.get("prism")?.show(); } })),
  h("input", { type: "color", value: S.accent, title: "Custom color", oninput: (e) => { S.accent = e.target.value; applyLook(); }, onchange: () => { save(); wins.get("prism")?.show(); } }));
const SEC = {
  appearance: () => [h("h1", {}, "Appearance"),
    h("div", { class: "group" , style: "padding:16px" }, h("div", { class: "modes" }, ["light", "dark", "auto"].map((m) => h("div", { class: "mode " + m + (S.theme === m ? " on" : ""), onclick: () => setTheme(m) }, h("i"), h("span", {}, { light: "Light", dark: "Dark", auto: "Auto" }[m]))))),
    h("div", { class: "group" },
      row("Accent color", null, swatches()),
      row("Glass opacity", "Lower values show more of the wallpaper", range(.15, .85, .01, S.glass, (v) => { S.glass = v; applyLook(); })),
      row("Glass blur", null, range(6, 60, 1, S.blur, (v) => { S.blur = v; applyLook(); })),
      row("Icon size", null, seg([[52, "Small"], [64, "Medium"], [80, "Large"]], S.iconSize, (v) => setIconSize(+v))))],
  wallpaper: () => [h("h1", {}, "Wallpaper"),
    h("div", { class: "group" }, h("div", { class: "wgrid" },
      ...WALLS.map((wl) => h("button", { class: "wt" + (S.wp === wl.id ? " on" : ""), onclick: () => { S.wp = wl.id; applyWall(); save(); wins.get("prism")?.show(); } }, h("i", { style: `background:${wl.css}` }), h("span", {}, wl.name))),
      customWp ? h("button", { class: "wt" + (S.wp === "custom" ? " on" : ""), onclick: () => { S.wp = "custom"; applyWall(); save(); wins.get("prism")?.show(); } }, h("i", { style: `background:url("${customWp}") center/cover` }), h("span", {}, "Your image")) : null)),
    h("div", { class: "btns", style: "margin-top:0;justify-content:flex-start" }, h("button", { class: "btn primary", onclick: () => $("#wpFile").click() }, "Choose Image\u2026"),
      customWp ? h("button", { class: "btn", onclick: () => { customWp = null; chrome.storage.local.remove("luma_wp"); if (S.wp === "custom") S.wp = "aurora"; applyWall(); save(); wins.get("prism")?.show(); } }, "Remove Image") : null)],
  home: () => [h("h1", {}, "Home"),
    h("div", { class: "group" },
      row("Greeting", "Good morning, Welcome back and so on", sw(S.showGreeting, (v) => { S.showGreeting = v; save(); renderHome(); })),
      row("Your name", S.autoName ? "Taken from your Google account: " + S.autoName : "Chrome didn't share your Google account (you need to be signed in to Chrome), so type a name", h("input", { type: "text", class: "txt", value: S.name, placeholder: S.autoName || "Name", oninput: (e) => { S.name = e.target.value.trim(); updateGreet(); }, onchange: save })),
      row("Search bar", null, sw(S.showSearch, (v) => { S.showSearch = v; save(); renderHome(); })),
      row("Search engine", null, seg([["google", "Google"], ["ddg", "DuckDuckGo"], ["bing", "Bing"]], S.engine, (v) => { S.engine = v; save(); renderHome(); })))],
  desktop: () => [h("h1", {}, "Desktop"),
    h("div", { class: "group" },
      row("Startup animation", "Plays when LumaOS opens", seg([["off", "Off"], ["session", "Once per session"], ["always", "Every tab"]], S.boot, (v) => { S.boot = v; applyLook(); save(); })),
      row("Open shortcuts in", null, seg([["same", "This tab"], ["tab", "New tab"]], S.openIn, (v) => { S.openIn = v; save(); }))),
    h("div", { class: "btns", style: "margin-top:0;justify-content:flex-start" }, h("button", { class: "btn", onclick: replayBoot }, "Replay Startup Animation"))],
  overlay: () => [h("h1", {}, "Site Panel"),
    h("div", { class: "group" },
      row("Show on websites", "A shortcut panel on every page you visit", sw(S.overlay, (v) => { S.overlay = v; save(); })),
      row("Edge", null, seg([["right", "Right"], ["left", "Left"]], S.side, (v) => { S.side = v; save(); })),
      row("Shortcut key", "Change it at chrome://extensions/shortcuts", h("span", { class: "sub" }, "Alt + L"))),
    h("div", { class: "sub" }, "The panel can't appear on Chrome system pages or the Chrome Web Store.")],
  about: () => [h("div", { class: "about" }, h("div", { html: logoSvg(72) }), h("h2", {}, "LumaOS"), h("p", {}, "Version 2.0.0"), h("p", {}, "A glass desktop for your new tab.")),
    h("div", { class: "btns", style: "justify-content:center" },
      h("button", { class: "btn", onclick: exportLayout }, "Export Layout\u2026"), h("button", { class: "btn", onclick: () => $("#importFile").click() }, "Import Layout\u2026"),
      h("button", { class: "btn danger", onclick: () => confirmBox({ title: "Reset LumaOS?", msg: "All categories, shortcuts and settings will be erased.", ok: "Reset", danger: true, run: async () => { await chrome.storage.local.remove("luma_wp"); customWp = null; S = defaults(); await save(); wallKey = ""; refreshAll(); } }) }, "Reset\u2026"))]
};
$("#wpFile").addEventListener("change", (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  const img = new Image(), url = URL.createObjectURL(f);
  img.onload = () => {
    const k = Math.min(1, 2200 / Math.max(img.width, img.height)), c = document.createElement("canvas");
    c.width = img.width * k; c.height = img.height * k; c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    customWp = c.toDataURL("image/jpeg", .86); URL.revokeObjectURL(url);
    chrome.storage.local.set({ luma_wp: customWp }); S.wp = "custom"; applyWall(); save(); wins.get("prism")?.show();
  };
  img.src = url;
});
function exportLayout() {
  const blob = new Blob([JSON.stringify(S, (k, v) => (k === "data" ? undefined : v), 2)], { type: "application/json" });
  h("a", { href: URL.createObjectURL(blob), download: "lumaos-layout.json" }).click();
}
$("#importFile").addEventListener("change", async (e) => {
  const f = e.target.files[0]; e.target.value = ""; if (!f) return;
  try {
    const j = JSON.parse(await f.text()); if (!Array.isArray(j.spaces) || !j.spaces.length) throw 0;
    S = { ...defaults(), ...j, wp: j.wp === "custom" && !customWp ? "aurora" : j.wp };
    S.spaces.forEach((sp) => { sp.icon = sp.icon || "folder"; sp.color = sp.color || LUMA_COLORS[0]; sp.items = (sp.items || []).map((i) => ({ id: i.id || uid(), name: i.name, url: i.url, icon: i.icon || "", data: "" })); });
    if (!S.spaces.some((s) => s.id === S.active)) S.active = S.spaces[0].id;
    save(); refreshAll(); ensureIcons(); toast("Layout imported");
  } catch { toast("That file isn't a LumaOS layout"); }
});

/* ---------- Launcher ---------- */
let launcher = null;
function openLauncher() {
  if (launcher) return closeLauncher();
  closeMenu(true);
  const input = h("input", { placeholder: "Search shortcuts, categories and actions", autocomplete: "off", spellcheck: "false" });
  const list = h("div", { class: "lres" });
  const el = h("div", { class: "launcher glass" }, h("div", { class: "lsearch" }, ic("search", 20, 2), input), list);
  $("#layer").append(el);
  launcher = { el, input, list, rows: [], sel: 0 };
  input.addEventListener("input", () => { launcher.sel = 0; renderLauncher(); });
  input.addEventListener("keydown", (e) => {
    const L = launcher; if (!L) return;
    if (e.key === "ArrowDown") { e.preventDefault(); L.sel = Math.min(L.sel + 1, L.rows.length - 1); renderLauncher(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); L.sel = Math.max(L.sel - 1, 0); renderLauncher(); }
    else if (e.key === "Enter") { e.preventDefault(); const r = L.rows[L.sel]; if (r) { closeLauncher(); r.run(e); } }
  });
  renderLauncher(); input.focus();
}
function closeLauncher() { if (!launcher) return; const { el } = launcher; launcher = null; el.classList.add("out"); setTimeout(() => el.remove(), 140); }
const renderLauncherIfOpen = () => { if (launcher) renderLauncher(); };
function renderLauncher() {
  const L = launcher, q = L.input.value.trim().toLowerCase(), rows = [];
  const act = (icon, label, run) => ({ label, sub: "Action", icon: h("div", { class: "act", html: lumaIcon(icon, 16, 2) }), run });
  const actions = [act("sliders", "Prism Settings", () => openSettings()), act("plus", "New Shortcut", () => editShortcut()), act("plus", "New Category", () => editSpace()),
    act("download", "Save Open Tabs Here", saveTabs), act(isDark() ? "sun" : "moon", isDark() ? "Switch to Light" : "Switch to Dark", () => setTheme(isDark() ? "light" : "dark")), act("sidebar", "Toggle Sidebar", () => toggleSidebar())];
  const cats = S.spaces.map((sp) => ({ label: sp.name, sub: "Category", icon: h("div", { class: "cat", style: `--c:${sp.color}`, html: lumaIcon(sp.icon, 16, 2) }), run: () => setActive(sp.id) }));
  if (!q) rows.push(...actions, ...cats);
  else {
    for (const sp of S.spaces) for (const it of sp.items) if (it.name.toLowerCase().includes(q) || it.url.toLowerCase().includes(q)) rows.push({ label: it.name, sub: sp.name, icon: h("div", { class: "mini" }, makeTile(it)), run: (e) => openItem(it, e) });
    rows.push(...actions.filter((a) => a.label.toLowerCase().includes(q)), ...cats.filter((c) => c.label.toLowerCase().includes(q)));
    const u = /^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(q) ? normalizeUrl(q) : null;
    if (u) rows.push({ label: `Go to ${q}`, sub: "Website", icon: h("div", { class: "act", html: lumaIcon("globe", 16, 2) }), run: () => (location.href = u) });
    rows.push({ label: `Search the web for \u201c${L.input.value.trim()}\u201d`, sub: "Google", icon: h("div", { class: "act", html: lumaIcon("search", 16, 2) }), run: () => (location.href = "https://www.google.com/search?q=" + encodeURIComponent(L.input.value.trim())) });
  }
  L.rows = rows; L.sel = Math.min(L.sel, rows.length - 1); L.list.textContent = "";
  rows.forEach((r, i) => L.list.append(h("div", { class: "lr" + (i === L.sel ? " sel" : ""), onpointermove: () => { if (L.sel !== i) { L.sel = i; [...L.list.children].forEach((c, j) => c.classList.toggle("sel", j === i)); } }, onclick: (e) => { closeLauncher(); r.run(e); } }, r.icon, h("div", { class: "l1" }, r.label), h("div", { class: "l2" }, r.sub))));
  L.list.children[L.sel]?.scrollIntoView({ block: "nearest" });
}

/* ---------- Home: greeting and search ---------- */
const ENGINES = { google: ["Google", "https://www.google.com/search?q="], ddg: ["DuckDuckGo", "https://duckduckgo.com/?q="], bing: ["Bing", "https://www.bing.com/search?q="] };
let welcomeFirst = null;
function greetingText() {
  if (welcomeFirst === null) {
    welcomeFirst = true;
    try { if (sessionStorage.getItem("luma_greeted")) welcomeFirst = false; sessionStorage.setItem("luma_greeted", "1"); } catch {}
  }
  const hr = new Date().getHours();
  const g = welcomeFirst ? "Welcome back" : hr < 5 ? "Good night" : hr < 12 ? "Good morning" : hr < 17 ? "Good afternoon" : hr < 22 ? "Good evening" : "Good night";
  const n = S.name || S.autoName;
  return n ? `${g}, ${n}` : g;
}
function updateGreet() { const g = $("#greet"); if (g && S) g.textContent = greetingText(); }
function goSearch(q, e) {
  q = q.trim(); if (!q) return;
  const looksUrl = /^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(q) || /^https?:\/\//i.test(q);
  const dest = (looksUrl && normalizeUrl(q)) || ENGINES[S.engine || "google"][1] + encodeURIComponent(q);
  if (e && (e.metaKey || e.ctrlKey)) chrome.tabs.create({ url: dest, active: false });
  else if (S.openIn === "tab") chrome.tabs.create({ url: dest });
  else location.href = dest;
}
function buildSearch() {
  const eng = ENGINES[S.engine] || ENGINES.google;
  const input = h("input", { id: "searchInput", type: "text", placeholder: `Search ${eng[0]} or type a URL`, autocomplete: "off", spellcheck: "false", "aria-label": "Search" });
  const drop = h("div", { class: "sdrop glass", hidden: true });
  let rows = [], sel = -1;
  const draw = () => {
    drop.textContent = ""; drop.hidden = !rows.length;
    rows.forEach((it, i) => drop.append(h("div", { class: "sr" + (i === sel ? " sel" : ""), onpointerdown: (e) => e.preventDefault(), onclick: (e) => openItem(it, e),
      onpointermove: () => { if (sel !== i) { sel = i; [...drop.children].forEach((c, j) => c.classList.toggle("sel", j === i)); } } },
      h("div", { class: "mini" }, makeTile(it)), h("div", { class: "sn" }, it.name), h("div", { class: "ss" }, (() => { try { return new URL(it.url).hostname; } catch { return ""; } })()))));
  };
  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase(); sel = -1;
    rows = q ? S.spaces.flatMap((sp) => sp.items).filter((it) => it.name.toLowerCase().includes(q) || it.url.toLowerCase().includes(q)).slice(0, 5) : [];
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); sel = Math.min(sel + 1, rows.length - 1); draw(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(sel - 1, -1); draw(); }
    else if (e.key === "Enter") { e.preventDefault(); if (sel >= 0 && rows[sel]) openItem(rows[sel], e); else goSearch(input.value, e); }
    else if (e.key === "Escape") { e.stopPropagation(); input.value = ""; rows = []; draw(); input.blur(); }
  });
  input.addEventListener("blur", () => setTimeout(() => { rows = []; draw(); }, 120));
  return h("div", { class: "sbox" }, h("div", { class: "sbar glass" }, ic("search", 19, 2), input, h("span", { class: "kbd" }, "/")), drop);
}
function renderHome() {
  const home = $("#home"); home.textContent = "";
  home.hidden = !(S.showGreeting || S.showSearch); if (home.hidden) return;
  if (S.showGreeting) {
    home.append(h("h1", { id: "greet", title: "Click to change your name", onclick: editName }, greetingText()));
    if (!(S.name || S.autoName)) home.append(h("button", { class: "namebtn glass", onclick: editName }, "Add your name"));
  }
  if (S.showSearch) home.append(buildSearch());
}
async function detectName() {
  try {
    let info = await chrome.identity.getProfileUserInfo({ accountStatus: "ANY" });
    if (!info || !info.email) info = await chrome.identity.getProfileUserInfo();
    const local = (info && info.email ? info.email.split("@")[0] : "");
    if (!local) return;
    const first = local.split(/[._\-+\d]+/).filter(Boolean)[0] || local;
    const nm = first.charAt(0).toUpperCase() + first.slice(1).toLowerCase();
    if (nm !== S.autoName) { S.autoName = nm; save(); renderHome(); }
  } catch {}
}

function editName() {
  closeById("name");
  const input = h("input", { type: "text", value: S.name || S.autoName || "", placeholder: "Your name", maxlength: "30" });
  createWindow({ id: "name", title: "Your Name", icon: "home", w: 360, pad: true, build: (w, b) => {
    b.append(h("form", { onsubmit: (e) => { e.preventDefault(); S.name = input.value.trim(); save(); renderHome(); closeWin(w); } },
      field("What should LumaOS call you?", input),
      h("div", { class: "btns" }, h("button", { type: "button", class: "btn", onclick: () => closeWin(w) }, "Cancel"), h("button", { type: "submit", class: "btn primary" }, "Save"))));
    setTimeout(() => input.focus(), 60);
  } });
}

/* ---------- Boot, keys, init ---------- */
let bootTimer;
function endBoot() { clearTimeout(bootTimer); document.documentElement.dataset.boot = "off"; }
function startBootTimer() { bootTimer = setTimeout(endBoot, 3800); $("#boot").onclick = endBoot; }
function replayBoot() {
  closeMenu(true); [...wins.values()].forEach(closeWin); toggleSidebar(false);
  document.documentElement.dataset.boot = "off"; void document.documentElement.offsetWidth; document.documentElement.dataset.boot = "on"; startBootTimer();
}
addEventListener("keydown", (e) => {
  const m = e.metaKey || e.ctrlKey, inField = e.target.matches?.("input");
  if (m && e.key.toLowerCase() === "k") { e.preventDefault(); openLauncher(); }
  else if (m && e.key === ",") { e.preventDefault(); openSettings(); }
  else if (e.key === "/" && !inField && $("#searchInput")) { e.preventDefault(); $("#searchInput").focus(); }
  else if (m && /^[1-9]$/.test(e.key) && !inField && S.spaces[+e.key - 1]) { e.preventDefault(); setActive(S.spaces[+e.key - 1].id); }
  else if (e.key === "Escape") {
    if (curMenu) closeMenu(); else if (launcher) closeLauncher();
    else if ($("#sidebar").classList.contains("open")) toggleSidebar(false);
    else { const top = [...wins.values()].filter((w) => !w.min).sort((a, b) => +b.el.style.zIndex - +a.el.style.zIndex)[0]; if (top) closeWin(top); }
  }
});
function refreshAll() { applyLook(); applyWall(); renderBar(); renderDock(); renderDesktop(false); renderSidebar(); renderHome(); }
(async () => {
  await load(); refreshAll(); setInterval(tick, 15000); ensureIcons(); detectName();
  if (document.documentElement.dataset.boot === "on") startBootTimer();
})();
