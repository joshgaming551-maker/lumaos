(() => {
  if (window.top !== window || document.getElementById("luma-host")) return;
  let S = null, active = null, open = false, tall = false;
  const send = (m) => { try { chrome.runtime.sendMessage(m); } catch {} };
  const host = document.createElement("div");
  host.id = "luma-host"; host.style.cssText = "all:initial;position:fixed;z-index:2147483647;top:0;left:0;";
  const root = host.attachShadow({ mode: "open" });
  root.innerHTML = `<style>
    :host{all:initial}
    .r{--font:-apple-system,BlinkMacSystemFont,"SF Pro Text","Inter","Segoe UI",system-ui,sans-serif;--ease:cubic-bezier(.22,1,.36,1);font:13px/1.4 var(--font);color:var(--fg);letter-spacing:-.003em}
    .r[data-t="light"]{--fg:#1c1c1e;--fg2:rgba(60,60,67,.62);--g:rgb(255 255 255/var(--ga));--edge:rgba(255,255,255,.6);--sep:rgba(0,0,0,.1);--hv:rgba(0,0,0,.07);--sh:0 0 0 .5px rgba(0,0,0,.14),0 20px 50px rgba(0,0,0,.25);--off:#d3d3d6}
    .r[data-t="dark"]{--fg:#f5f5f7;--fg2:rgba(235,235,245,.6);--g:rgb(34 34 40/var(--ga));--edge:rgba(255,255,255,.14);--sep:rgba(255,255,255,.12);--hv:rgba(255,255,255,.1);--sh:0 0 0 .5px rgba(0,0,0,.6),0 20px 50px rgba(0,0,0,.55);--off:#4a4a50}
    .glass{background:var(--g);border:.5px solid var(--edge);box-shadow:var(--sh);backdrop-filter:blur(var(--bl)) saturate(190%);-webkit-backdrop-filter:blur(var(--bl)) saturate(190%)}
    *{box-sizing:border-box}button{all:unset;box-sizing:border-box;cursor:default}
    .handle{position:fixed;top:50%;width:20px;height:78px;margin-top:-39px;display:grid;place-items:center;transition:width .25s var(--ease),opacity .2s}
    .handle.right{right:0;border-radius:14px 0 0 14px;border-right:0}.handle.left{left:0;border-radius:0 14px 14px 0;border-left:0}
    .handle:hover{width:28px}.handle.hide{opacity:0;pointer-events:none}
    .handle svg{width:14px;height:14px}
    .panel{position:fixed;top:50%;width:352px;max-width:calc(100vw - 24px);max-height:62vh;border-radius:18px;display:flex;flex-direction:column;overflow:hidden;opacity:0;pointer-events:none;transition:opacity .25s,transform .45s var(--ease),max-height .35s var(--ease)}
    .panel.right{right:14px;transform:translate(40px,-50%) scale(.95)}.panel.left{left:14px;transform:translate(-40px,-50%) scale(.95)}
    .panel.open{opacity:1;pointer-events:auto;transform:translate(0,-50%) scale(1)}.panel.tall{max-height:86vh}
    .tb{height:44px;flex:none;display:flex;align-items:center;padding:0 14px;position:relative}
    .lights{display:flex;gap:8px;z-index:1}.lt{width:12px;height:12px;border-radius:50%;border:.5px solid rgba(0,0,0,.2);display:grid;place-items:center}
    .lt.r{background:#ff5f57}.lt.y{background:#febc2e}.lt.g{background:#28c840}.lt span{opacity:0;line-height:0}.lights:hover .lt span{opacity:1}
    .panel:not(:hover) .lt:not(.r){}
    .title{position:absolute;left:0;right:0;text-align:center;font-weight:600;pointer-events:none}
    .chips{display:flex;gap:6px;padding:0 12px 10px;overflow-x:auto;flex:none;scrollbar-width:none}.chips::-webkit-scrollbar{display:none}
    .chip{display:inline-flex;align-items:center;gap:6px;height:26px;padding:0 11px;border-radius:13px;background:var(--hv);white-space:nowrap;font-size:12px;flex:none}
    .chip.on{background:var(--ac);color:#fff}.chip svg{width:13px;height:13px}
    .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px 4px;padding:6px 12px 14px;overflow:auto;flex:1}
    .it{display:flex;flex-direction:column;align-items:center;gap:6px;padding:6px 2px;border-radius:10px}.it:hover{background:var(--hv)}
    .tile{width:52px;height:52px;border-radius:12px;background:linear-gradient(180deg,#fff,#eef0f5);display:grid;place-items:center;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,.25),0 0 0 .5px rgba(0,0,0,.14);transition:transform .25s var(--ease)}
    .it:hover .tile{transform:translateY(-2px)}.it:active .tile{transform:scale(.94)}
    .tile img{width:56%;height:56%;object-fit:contain}.tile.photo img{width:100%;height:100%;object-fit:cover}
    .tile b{width:100%;height:100%;display:grid;place-items:center;color:#fff;font-size:22px}
    .nm{font-size:11px;text-align:center;max-width:76px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;word-break:break-word}
    .empty{grid-column:1/-1;text-align:center;color:var(--fg2);padding:26px 10px}
    .ft{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 14px;border-top:.5px solid var(--sep);color:var(--fg2);font-size:11px;flex:none}
    .btn{padding:4px 12px;border-radius:7px;background:var(--ac);color:#fff;font-size:12px}
    @media (prefers-reduced-motion:reduce){*{transition:none!important}}
  </style><div class="r" data-t="dark"><button class="handle glass right hide" aria-label="Open LumaOS panel"></button><div class="panel glass right" role="dialog" aria-label="LumaOS shortcuts"></div></div>`;
  const R = root.querySelector(".r"), handle = root.querySelector(".handle"), panel = root.querySelector(".panel");
  const g = (p) => `<span><svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="rgba(0,0,0,.55)" stroke-width="1.3" stroke-linecap="round"><path d="${p}"/></svg></span>`;
  const favUrl = (u) => { try { return `https://www.google.com/s2/favicons?sz=128&domain=${new URL(u).hostname}`; } catch { return ""; } };
  const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };

  function theme() {
    const dark = S.theme === "dark" || (S.theme === "auto" && matchMedia("(prefers-color-scheme: dark)").matches);
    R.dataset.t = dark ? "dark" : "light";
    R.style.setProperty("--ac", S.accent || "#0a84ff"); R.style.setProperty("--ga", S.glass ?? .5); R.style.setProperty("--bl", (S.blur ?? 34) + "px");
  }
  function render() {
    if (!S || !S.spaces) { handle.classList.add("hide"); return; }
    theme();
    const side = S.side === "left" ? "left" : "right";
    handle.className = "handle glass " + side + (S.overlay === false || open ? " hide" : "");
    panel.className = "panel glass " + side + (open ? " open" : "") + (tall ? " tall" : "");
    handle.innerHTML = `<svg viewBox="0 0 48 48"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffc371"/><stop offset=".55" stop-color="#ff5f8d"/><stop offset="1" stop-color="#7a5cff"/></linearGradient></defs><circle cx="24" cy="24" r="21" fill="url(#g)"/><circle cx="24" cy="24" r="6.5" fill="#fff"/></svg>`;
    if (!active || !S.spaces.some((s) => s.id === active)) active = S.active && S.spaces.some((s) => s.id === S.active) ? S.active : S.spaces[0]?.id;
    panel.textContent = "";
    const tb = el("div", "tb"), lights = el("div", "lights");
    [["r", "M3.5 3.5l5 5M8.5 3.5l-5 5", () => toggle(false)], ["y", "M3 6h6", () => toggle(false)], ["g", "M3.5 6h5M6 3.5v5", () => { tall = !tall; render(); }]].forEach(([c, p, fn]) => { const b = el("button", "lt " + c); b.innerHTML = g(p); b.onclick = fn; lights.append(b); });
    tb.append(lights, el("div", "title", "LumaOS"));
    const chips = el("div", "chips");
    S.spaces.forEach((sp) => {
      const b = el("button", "chip" + (sp.id === active ? " on" : ""));
      b.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${LUMA_ICONS[sp.icon] || LUMA_ICONS.folder}</svg>`;
      b.append(sp.name); b.onclick = () => { active = sp.id; render(); }; chips.append(b);
    });
    const grid = el("div", "grid"), sp = S.spaces.find((s) => s.id === active);
    if (!sp || !sp.items.length) grid.append(el("div", "empty", "Nothing here yet. Add shortcuts from your LumaOS new tab."));
    else sp.items.forEach((it) => {
      const b = el("button", "it"), t = el("div", "tile" + (it.icon ? " photo" : ""));
      const letter = () => { t.className = "tile"; t.textContent = ""; const l = el("b", "", (it.name[0] || "?").toUpperCase()); l.style.background = `hsl(${[...it.name].reduce((a, c) => a + c.charCodeAt(0), 0) % 360} 55% 50%)`; t.append(l); };
      const src = it.data || it.icon || favUrl(it.url);
      if (src) { const im = el("img"); im.alt = ""; im.src = src; im.onerror = letter; t.append(im); } else letter();
      b.append(t, el("div", "nm", it.name)); b.title = it.url;
      b.onclick = (e) => send({ type: "open", url: it.url, active: !(e.metaKey || e.ctrlKey) });
      b.oncontextmenu = (e) => { e.preventDefault(); send({ type: "popout", url: it.url }); };
      grid.append(b);
    });
    const ft = el("div", "ft"), hint = el("span", "", "Right-click an icon to pop it out"), home = el("button", "btn", "Open LumaOS");
    home.onclick = () => send({ type: "open" }); ft.append(hint, home);
    panel.append(tb, chips, grid, ft);
  }
  function toggle(v) { open = v ?? !open; render(); }
  document.addEventListener("pointerdown", (e) => { if (open && !e.composedPath().includes(host)) toggle(false); }, true);
  document.addEventListener("keydown", (e) => { if (open && e.key === "Escape") toggle(false); }, true);
  handle.addEventListener("click", () => toggle(true));
  try {
    chrome.runtime.onMessage.addListener((m) => { if (m.type === "toggle" && S && S.spaces) toggle(); });
    chrome.storage.onChanged.addListener((c, a) => { if (a === "local" && c.luma) { S = c.luma.newValue; render(); } });
    chrome.storage.local.get("luma").then((r) => { S = r.luma || null; render(); });
  } catch {}
  document.documentElement.append(host);
})();
